module.exports = {
  // configure the code below with your username, password and mlab database information
 // database: 'mongodb+srv://admin:admin@cluster0-rkmn7.mongodb.net/test?retryWrites=true&w=majority',   //prod
  database: 'mongodb+srv://admin:admin@digifiletest1-o6t78.mongodb.net/test?retryWrites=true&w=majority',   //prod
  //database: 'mongodb://localhost:27017/meanauth',    //dev
  secret: 'yoursecret'
}
